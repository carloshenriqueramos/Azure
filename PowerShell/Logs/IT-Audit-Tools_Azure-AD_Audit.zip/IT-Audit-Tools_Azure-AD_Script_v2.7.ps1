param ([switch] $LimitGroupMemberMode, [switch] $DisableFileRemoval, [string]$TenantId)

# Folder to temporarily store the data in
$outputDirectory = "azure_ad_analysis"
$requiredPowershellVersion = 5
#dynamic
$version = '2.7'

# download timestamp in ISO-8601 format yyyy-MM-dd
#dynamic
$downloadTimestamp = '2023-05-24'
$numberOfMonthsValid = 3
$script:errors = @()
$script:licenseErrorOccurred = $false

$validUntil = [System.DateTime]::ParseExact($downloadTimestamp, "yyyy-MM-dd", $null).AddMonths($numberOfMonthsValid)

$priviligedAccessRoles = @(
    'c4e39bd9-1100-46d3-8c65-fb160da0071f',
    '0526716b-113d-4c15-b2c8-68e3c22b9f80',
    'b1be1c3e-b65d-4f19-8427-f6fa0d97feb9',
    '9360feb5-f418-4baa-8175-e2a00bac4301',
    '62e90394-69f5-4237-9190-012177145e10',
    '729827e3-9c14-49f7-bb1b-9608f156bbb8',
    '966707d0-3269-4727-9be2-8c3a10f19b9d',
    '7be44c8a-adaf-4e2a-84d6-ab2649e08a13',
    'e8611ab8-c189-46e8-94e1-60213ab1f814',
    '194ae4cb-b126-40b2-bd5b-6091b380977d',
    '5f2222b1-57c3-48ba-8ad5-d4759f1fde6f',
    'fe930be7-5e62-47db-91af-98c3a49a38b1'
    )

#region Functions
function Log-Error-And-Stop {
    param (
        [string] $message,
        $Exception
    )
    # save the current color
    $originalForegroundColor = $host.UI.RawUI.ForegroundColor

    # set the new color
    $host.UI.RawUI.ForegroundColor = "red"

    Write-Output "Error: $message" | Out-Host
    Write-Output $Exception.Message | Out-Host
    Write-Output $Exception.ItemName | Out-Host

    # restore the original color
    $host.UI.RawUI.ForegroundColor = $originalForegroundColor

    Write-Output "Press any key to abort script ..." | Out-Host
    $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    try {
        stop-transcript | out-null
    } catch [System.InvalidOperationException] {
        Write-Error "Transcript stopped"
    }
    exit
}

function Log-Success-Message {
    param (
        [string] $message
    )

     # save the current color
     $originalForegroundColor = $host.UI.RawUI.ForegroundColor

     # set the new color
     $host.UI.RawUI.ForegroundColor = "green"

    Write-Output "$message .......OK!" | Out-Host

    # restore the original color
    $host.UI.RawUI.ForegroundColor = $originalForegroundColor
}

function Test-MsGraphInstalled {
    Write-Output "Checking if the Microsoft Graph Module is installed...." | Out-Host

    if (Get-InstalledModule -Name "Microsoft.Graph" -MinimumVersion "1.10.0" -erroraction 'silentlycontinue') {
        return $true
    }
}

function Stop-OnRestrictedLanguageMode {
    <# Check if the full language mode is used, otherwise methods can't be used, which breaks the whole script #>
    if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
        $errorMessage = "`nError: It seems that you're using a restricted version of Powershell. Please use the Full Language Mode'`n"

        Write-Error $errorMessage
        Write-Output "Script has been aborted, please use powershell with Full Language Mode ..."

        stop-transcript
        break
    } else {
        Log-Success-Message -message "Correct Language Mode is used"
    }
}

function Stop-OnMsGraphNotInstalled {
    if (Test-MsGraphInstalled) {
        Log-Success-Message -message "Microsoft Graph Module installed"
    } else {
        Log-Error-And-Stop -message "The Microsoft Graph Module or the right version (1.10.0) is not installed. Please install or update the module using Install-Module Microsoft.Graph or Update-Module Microsoft.Graph"
    }
}

function Stop-OnScriptExpired {
    param (
        $validUntil
    )
    Write-Output "Checking if the script is not expired....." | Out-Host
    if ([System.DateTime]::Now -gt $validUntil) {
        $validUntilFormatted = $validUntil.ToShortDateString()
        $errorMessage = "The script was valid until $validUntilFormatted and can no longer be run. Please contact your auditor to acquire a new version of the script."
        Log-Error-And-Stop $errorMessage
    } else {
        Log-Success-Message "Script has not expired yet"
    }
}

function Stop-OnUnsupportedPowerShellVersion {
    Write-Output "Checking PowerShell version....." | Out-Host
    if ($PSVersionTable.PSVersion.Major -lt $requiredPowershellVersion) {
        Log-Error-And-Stop "The minimum PowerShell version for this script is $requiredPowershellVersion, please update PowerShell and try again"
    } else {
        Write-Output "Powershell $requiredPowershellVersion or higher is used" | Out-Host
    }
}

function Test-Prerequisites {
    Write-Output "Starting requirements checks....." | Out-Host
    Stop-OnRestrictedLanguageMode
    Stop-OnUnsupportedPowerShellVersion
    Stop-OnScriptExpired -validUntil $validUntil
    Stop-OnMsGraphNotInstalled
    Log-Success-Message "Requirement checks completed"
}

function Export-ToJSON {
    param (
        [Parameter(Mandatory = $true)]
        [string] $filename,
        [string] $shouldBeArray,
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$dataObject,
        [string] $outputDirectory = $outputDirectory
    )
    if ((!($dataObject -is [array])) -and ($shouldBeArray -eq $true)) {
        $dataObject = @($dataObject)
    }
    try {
        ConvertTo-Json $dataObject -Depth 5 -WarningAction SilentlyContinue | Out-File -FilePath ("$outputDirectory\$filename.json")
    } catch {
        Write-Output $_.Exception.Message | Out-Host
        Write-Output $_.Exception.ItemName | Out-Host
        Log-Error-And-Stop "Something went wrong trying to export $filename" -Exception $_.Exception
    }
}

function Export-Data-Objects {
    param (
        [Parameter(Mandatory = $true)]
        [Hashtable] $dataObjects,
        [string] $outputDirectory
    )
    Write-Output "Exporting data to output directory....." | Out-Host
    Foreach ($i in $dataObjects.GetEnumerator()) {
        $shouldBeArray = $i.Value.shouldBeArray
        $dataObject = $i.Value.data
        if ($dataObject) {
            $filename = $i.Key
            Write-Debug "Exporting $filename to JSON....."
            Export-ToJSON -filename $filename -dataObject $dataObject -outputDirectory $outputDirectory -shouldBeArray $shouldBeArray
            }
            Write-Output "Exported $filename to JSON" | Out-Host
            }
    Log-Success-Message "All data exported to output directory"
}

function Connect-ToMgGraph {
    param (
        [string] $TenantId
    )
    Write-Output "Connecting to Microsoft Graph....." | Out-Host
    try {
        $scopes = 'User.Read.All Directory.Read.All AuditLog.Read.All RoleAssignmentSchedule.Read.Directory, RoleManagement.Read.All, Policy.Read.All'
        if ($TenantId -eq "") {
            Connect-MgGraph -Scopes $scopes -ContextScope Process
        } else {
            Connect-MgGraph -Scopes $scopes -TenantId $TenantId -ContextScope Process
        }

        Select-MgProfile -Name "beta"
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong trying to connect to Azure Active Directory" -Exception $_.Exception
    }
}

function Get-SecurityDefaultPolicy {
    try {
        $policy = Get-MgPolicyIdentitySecurityDefaultEnforcementPolicy | Select-Object IsEnabled
        return $policy
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong retrieving the Default Security Policy" -Exception $_.Exception
    }
}

function Get-GeneralTenantData {
    Write-Output "Retrieving General Tenant Information....." | Out-Host
    try {
        $generalTenantData = Get-MgOrganization | Select-Object CreatedDateTime, DisplayName, Id, OnPremisesLastSyncDateTime, OnPremisesSyncEnabled, @{N='TenantType'; E={$_.AdditionalProperties['tenantType']}}, @{N='OnPremisesLastPasswordSyncDateTime'; E={$_.AdditionalProperties['onPremisesLastPasswordSyncDateTime']}}
        Log-Success-Message -message "Succesfully retrieved General Tenant Information"
        $generalTenantData | Add-Member -NotePropertyName LimitedGroupMemberMode -NotePropertyValue $LimitGroupMemberMode.IsPresent
        $securityDefaultPolicy = Get-SecurityDefaultPolicy
        $generalTenantData | Add-Member -NotePropertyName DefaultSecurityPolicy -NotePropertyValue $securityDefaultPolicy.IsEnabled
        return $generalTenantData
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong retrieving the General Tenant Information" -Exception $_.Exception
    }
}

function Get-Users {
    Write-Output "Retrieving Users....." | Out-Host
    try {
        $users = Get-MgUser -All -ErrorAction Stop -Property 'lastPasswordChangeDateTime, SignInActivity, DisplayName, Id, UserType, CreatedDateTime, JobTitle, AccountEnabled, PasswordPolicies, UserPrincipalName, OnPremisesSyncEnabled, OnPremisesLastSyncDateTime' | Select-Object lastPasswordChangeDateTime, @{N='LastSignInDateTime'; E={$_.SignInActivity.LastSignInDateTime}}, DisplayName, Id, UserType, CreatedDateTime, JobTitle, AccountEnabled, PasswordPolicies, UserPrincipalName, OnPremisesSyncEnabled, OnPremisesLastSyncDateTime
    }
    catch {
        if ($_.Exception.Code -eq "Authentication_RequestFromNonPremiumTenantOrB2CTenant") {
            Write-Output "No Sign-In Activity available due to license restrictions." | Out-Host
            Write-Output "Retrieving Users without Sign-In Activity....." | Out-Host
            $script:licenseErrorOccurred = $true;
            $users = Get-MgUser -All -ErrorAction Stop -Property 'lastPasswordChangeDateTime, DisplayName, Id, UserType, CreatedDateTime, JobTitle, AccountEnabled, PasswordPolicies, UserPrincipalName, OnPremisesSyncEnabled, OnPremisesLastSyncDateTime' | Select-Object lastPasswordChangeDateTime, DisplayName, Id, UserType, CreatedDateTime, JobTitle, AccountEnabled, PasswordPolicies, UserPrincipalName, OnPremisesSyncEnabled, OnPremisesLastSyncDateTime
        } else {
            Log-Error-And-Stop -message "Something went wrong retrieving the users" -Exception $_.Exception
        }
    }
    Log-Success-Message -message "Succesfully retrieved users"
    return $users
}

function Get-UserAuthenticationMethods {
    Write-Output "Retrieving Users Authentication Settings....." | Out-Host
    try {
        $authenticationSettings = Get-MgReportAuthenticationMethodUserRegistrationDetail -All -ErrorAction Stop | Select-Object Id, IsMfaRegistered, MethodsRegistered, IsSsprEnabled
        Log-Success-Message -message "Succesfully retrieved user authentication settings"
        return $authenticationSettings
    }
    catch {
        if ($_.Exception.Code -eq "Authentication_RequestFromNonPremiumTenantOrB2CTenant") {
            Write-Output "No authentication settings available due to license restrictions." | Out-Host
            $script:licenseErrorOccurred = $true;
            return
        }
        Log-Error-And-Stop -message "Something went wrong retrieving the user authentication settings" -Exception $_.Exception
    }
}

function Get-GroupMembers {
    param (
        $group
    )
    try {
        $members = Get-MgGroupMember -GroupId $group.Id -All -Property 'Id, AdditionalProperties' | Select-Object Id, @{N='ObjectType'; E={$_.AdditionalProperties['@odata.type']}}
        if ((!($members -is [array])) -or ($members['ObjectId'])) {
            $members = @($members)
        }
        $group | Add-Member -NotePropertyName Members -NotePropertyValue $members
    }
    catch {
        Write-Output $_.Exception.Message | Out-Host
        Write-Output $_.Exception.ItemName | Out-Host
        $errorMessage = "Warning: Something went wrong retrieving members for group ${group.DisplayName}"
        Write-Output $errorMessage | Out-Host
        $script:errors += $errorMessage
    }
}

function Get-Groups {
    param (
        $LimitGroupMemberMode
    )
    Write-Output "Retrieving Groups....." | Out-Host
    try {
        $groups = Get-MgGroup -All -Property 'Id, DisplayName, Description, IsAssignableToRole, Owners' -ExpandProperty 'Owners' | Select-Object Id, DisplayName, Description, IsAssignableToRole, Owners
        Log-Success-Message -message "Succesfully retrieved groups"

        Write-Output "Retrieving Groupmembers....." | Out-Host
        if ($LimitGroupMemberMode.IsPresent) {
            Write-Output "Retrieving Only groupmembers of role assignable groups....." | Out-Host
            $memberRetrievalGroups = $groups | Where-Object {$_.IsAssignableToRole -eq 'True'}
        } else {
            $memberRetrievalGroups = $groups
        }

        $groupCount = $groups.Length
        $i = 1
        foreach ($group in $memberRetrievalGroups) {
            $percentage = [Math]::Floor(($i / $groupCount) * 100)
            Write-Progress -Activity "Retrieving Group Members....." -Status "$percentage% Complete" -PercentComplete $percentage
            Get-GroupMembers -group $group
            $i++
        }
        Write-Progress -Activity "Retrieving Group Members....." -Completed $true
        return $groups;
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong retrieving the groups" -Exception $_.Exception
    }
}

function Get-DirectoryRoleMembers {
    param (
        $directoryRole
    )
    try {
        $members = Get-MgDirectoryRoleMember -DirectoryRoleId $directoryRole.Id -Property 'Id, AdditionalProperties' | Select-Object Id, @{N='ObjectType'; E={$_.AdditionalProperties['@odata.type']}}
        if ((!($members -is [array])) -or ($members['ObjectId'])) {
            $members = @($members)
        }
        $directoryRole | Add-Member -NotePropertyName Members -NotePropertyValue $members
    }
    catch {
        Write-Output $_.Exception.Message | Out-Host
        Write-Output $_.Exception.ItemName | Out-Host
        $errorMessage = "Warning: Something went wrong retrieving members for role ${directoryRole.DisplayName}"
        Write-Output $errorMessage | Out-Host
        $script:errors += $errorMessage
    }
}

function Get-DirectoryRoles {
    Write-Output "Retrieving Directory Roles....." | Out-Host
    try {
        $directoryRoles = Get-MgDirectoryRole -All -Property 'Id, RoleTemplateId, DisplayName, Description' | Select-Object Id, RoleTemplateId, DisplayName, Description
        Log-Success-Message -message "Succesfully retrieved the Directory Roles"

        foreach($directoryRole IN $directoryRoles) {
            Get-DirectoryRoleMembers -directoryRole $directoryRole
        }

        return $directoryRoles
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong retrieving the Directory Roles" -Exception $_.Exception
    }
}

function Get-EligibleDirectoryRoles {
    Write-Output "Retrieving Assigned Directory Roles (PIM)....." | Out-Host
    try {
        $assignments = Get-MgRoleManagementDirectoryRoleEligibilitySchedule -All -ErrorAction Stop -Property "principal, principalId, roleDefinition, roleDefinitionId, scheduleInfo, status, directoryScopeId" -ExpandProperty "roleDefinition, principal" |
            Select-Object @{N='PrincipalType'; E={$_.principal.AdditionalProperties['@odata.type']}}, PrincipalId, @{N='RoleName'; E={$_.roleDefinition.DisplayName}}, @{N='RoleTemplateId'; E={$_.roleDefinition.TemplateId}},
            RoleDefinitionId, Status, DirectoryScopeId, @{N='ScheduleEndDate'; E={$_.scheduleInfo.Expiration.EndDateTime}}, @{N='ScheduleExpirationType'; E={$_.scheduleInfo.Expiration.Type}}, @{N='ScheduleStartDate'; E={$_.scheduleInfo.StartDateTime}}

        Log-Success-Message -message "Succesfully retrieved the Directory Eligible Role Assignments"
        return $assignments
    }
    catch {
        if ($_.Exception.Code -eq "AadPremiumLicenseRequired") {
            Write-Output "No eligible roles available due to license restrictions." | Out-Host
            $script:licenseErrorOccurred = $true;
            return
        }
        Log-Error-And-Stop -message "Something went wrong retrieving the Eligible Role Assignments" -Exception $_.Exception
    }
}

function Get-RolePolicies {
    param(
        $priviligedAccessRoles
    )
    Write-Output "Retrieving Directory Role Policies (PIM)....." | Out-Host

    try {
        $policies = @()
        foreach ($role in $priviligedAccessRoles) {
            $rolePolicies = Get-MgPolicyRoleManagementPolicyAssignment -Filter "scopeId eq '/' and scopeType eq 'DirectoryRole' and roleDefinitionId eq '$role'" -ExpandProperty "policy(`$expand=rules)" -ErrorAction Stop
            if (($null -eq $rolePolicies) -or ($rolePolicies -eq "")) {
                continue
            }
            $rules = Get-MgPolicyRoleManagementPolicyRule -UnifiedRoleManagementPolicyId $rolePolicies.Policy.Id -Filter "id in ('Expiration_EndUser_Assignment', 'Enablement_EndUser_Assignment', 'Approval_EndUser_Assignment')" | Select-Object AdditionalProperties
            $policy = [PSCustomObject]@{
                TemplateId     = $role
                Rules = $rules
            }
            $policies += $policy
        }
        Log-Success-Message -message "Succesfully retrieved the Directory Role Policies"
        return $policies
    }
    catch {
        if ($_.Exception.Code -eq "AadPremiumLicenseRequired") {
            Write-Output "No role policies available due to license restrictions." | Out-Host
            $script:licenseErrorOccurred = $true;
            return
        }
        Log-Error-And-Stop -message "Something went wrong retrieving the Role Policies" -Exception $_.Exception
    }
}

function Get-Domains {
    Write-Output "Retrieving Directory Domains....." | Out-Host
    try {
        $domains = Get-MgDomain -All -Property 'Id, IsDefault, PasswordNotificationWindowInDays, PasswordValidityPeriodInDays' | Select-Object Id, IsDefault, PasswordNotificationWindowInDays, PasswordValidityPeriodInDays
        Log-Success-Message -message "Succesfully retrieved Domains"
        return $domains
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong retrieving Domains" -Exception $_.Exception
    }
}

function Get-Devices {
    Write-Output "Retrieving Devices....." | Out-Host
    try {
        $devices = Get-MgDevice -All -Property 'AccountEnabled, ApproximateLastSignInDateTime, DeviceId, DisplayName, IsCompliant, OnPremisesSyncEnabled, OnPremisesLastSyncDateTime, OperatingSystem, OperatingSystemVersion, Id, RegisteredUsers' | Select-Object AccountEnabled, ApproximateLastSignInDateTime, DeviceId, DisplayName, IsCompliant, OnPremisesSyncEnabled, OnPremisesLastSyncDateTime, OperatingSystem, OperatingSystemVersion, Id, RegisteredUsers
        Log-Success-Message -message "Succesfully retrieved Devices"
        return $devices
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong retrieving Devices" -Exception $_.Exception
    }
}

function Get-ConditionalAccessPolicies {
    Write-Output "Retrieving Conditional Access Policies....." | Out-Host
    try {
        $conditionalAccessPolicies = Get-MgIdentityConditionalAccessPolicy -All -Property 'Conditions, CreatedDateTime, DisplayName, GrantControls, Id, ModifiedDateTime, SessionControls, State' | Select-Object Conditions, CreatedDateTime, DisplayName, GrantControls, Id, ModifiedDateTime, SessionControls, State
        Log-Success-Message -message "Succesfully retrieved Conditional Access Policies"
        return $conditionalAccessPolicies
    }
    catch {
        Log-Error-And-Stop -message "Something went wrong retrieving the Conditional Access Policies" -Exception $_.Exception
    }
}

function Get-ScriptData {
    $systemInfo = [PSCustomObject]@{
        version = $version
        datetime = (get-date).ToString("dd-MM-yyyy HH:mm:ss")
        licenseErrorOccurred = $script:licenseErrorOccurred
    }
    return $systemInfo;
}

function Add-Script-To-Folder(){
    param (
        [Parameter(Mandatory = $true)]
        [string] $scriptPath,
        [Parameter(Mandatory = $true)]
        [string] $scriptName,
        [Parameter(Mandatory = $true)]
        [string] $destination
    )
    Copy-Item -Path ($scriptPath + "\" + $scriptName) -Destination ($destination + "\azure_ad.ps1")
    Write-Output "Added the used script to folder" | Out-Host
}

function Hash-Output {
    param (
        [string] $outputDirectory
    )
    $hashes = [PSCustomObject]@{}
    foreach ($file in Get-ChildItem $outputDirectory) {
        if ($file.Name.EndsWith('.ps1')) {
            $fileStream = [System.IO.File]::OpenText($file.FullName)
            $hashStream = Remove-DynamicLines -Stream $fileStream
            $fileStream.Close();
            $hashes | Add-Member -NotePropertyName $file.Name -NotePropertyValue (Hash-FileStream -fileStream $hashStream)
        } else {
            $hashes | Add-Member -NotePropertyName $file.Name -NotePropertyValue (Hash-File $file.FullName)
        }
    }
    Export-ToJSON -filename "Hashes" -dataObject $hashes -outputDirectory $outputDirectory
}

function Hash-File {
    param (
        [string] $fileLocation
    )
    Try {
        $fileStream = ([IO.StreamReader]$fileLocation).BaseStream
        return Hash-FileStream($fileStream);
    } Catch {
        Write-Output $_.Exception.Message | Out-Host
        Write-Output $_.Exception.ItemName | Out-Host
        Log-Error-And-Stop "Something went wrong trying to get a file stream for $fileLocation"
    }
}

function Hash-FileStream {
    param (
        $fileStream
    )
    Try {
        $hash = [Security.Cryptography.HashAlgorithm]::Create("sha1")
        $file_hash = -join ($hash.ComputeHash($fileStream) | ForEach-Object { "{0:x2}" -f $_ })
        $fileStream.Close()
        return $file_hash
    } Catch {
        Log-Error-And-Stop "Something went wrong trying to hash a file"
    }
}

function Remove-DynamicLines{
    param (
        $Stream
    )
    $newStream = New-Object System.IO.MemoryStream
    $writer = New-Object System.IO.StreamWriter -ArgumentList $newStream
    $newContent = "";
    [bool] $signature = 0;
    while($null -ne ($line = $Stream.ReadLine())) {
        if ($line -like '*#dynamic*') {
            ## Needs to write to variable to work
            $line = $Stream.ReadLine();
        } elseif(($line -like '*# SIG # Begin signature block*') -or ($signature)) {
            $signature = 1;
        }else {
            $newContent = $newContent  + $line + [Environment]::NewLine;
        }
    }

    $writer.Close();
    return New-Object IO.MemoryStream(,[Text.Encoding]::UTF8.GetBytes($newContent))
}

function New-Zip {
    param (
        [Parameter(Mandatory = $true)]
        [string] $zipFileName
    )

    try {
        Compress-Archive -Path "$outputDirectory\*" -DestinationPath $zipFileName -Update
    } catch {
        Log-Error-And-Stop -message "Something went wrong compressing the output files to a zip file"
    }
}

function Remove-Temp-Folder {
    param (
        [Parameter(Mandatory = $true)]
        [string] $outputDirectory
    )
    Remove-Item $outputDirectory -Recurse
}


#endregion Functions


$scriptPath = split-path -parent $MyInvocation.MyCommand.Definition
if ($scriptPath.Substring($scriptPath.Length - 1, 1) -ne '\') {
    $outputDirectory = $scriptPath + '\' + $outputDirectory
} else {
    $outputDirectory = $scriptPath + $outputDirectory
}
$scriptName = $MyInvocation.MyCommand.Name

#Start Script
Start-Transcript -Path ($outputDirectory + "\transcript.txt")
Write-Output "Starting Azure Active Directory PowerShell Script. The execution of this script will take several minutes depending on the size of the Azure Active Directory." | Out-Host

Test-Prerequisites
Connect-ToMgGraph -TenantId $TenantId

$generalTenantData = Get-GeneralTenantData
$users = Get-Users
$userAuthentication = Get-UserAuthenticationMethods
$groups = Get-Groups -LimitGroupMemberMode $LimitGroupMemberMode
$directoryRoles = Get-DirectoryRoles
$eligibleDirectoryRoles = Get-EligibleDirectoryRoles
$rolePolicies = Get-RolePolicies -priviligedAccessRoles $priviligedAccessRoles
$domains = Get-Domains
$devices = Get-Devices
$conditionalAccessPolicies = Get-ConditionalAccessPolicies
$scriptData = Get-ScriptData


Export-Data-Objects -outputDirectory $outputDirectory -dataObjects @{
    GeneralTenantAnalysis = [PSCustomObject]@{
        data     = $generalTenantData
        shouldBeArray = $false
    }
    AllUsersAnalysis      = [PSCustomObject]@{
        data     = $users
        shouldBeArray = $true
    }
    UserAuthenticationAnalysis      = [PSCustomObject]@{
        data     = $userAuthentication
        shouldBeArray = $true
    }
    AllGroupsAnalysis     = [PSCustomObject]@{
        data     = $groups
        shouldBeArray = $true
    }
    AllRolesAnalysis      = [PSCustomObject]@{
        data     = $directoryRoles
        shouldBeArray = $true
    }
    AllEligibleRolesAnalysis      = [PSCustomObject]@{
        data     = $eligibleDirectoryRoles
        shouldBeArray = $true
    }
    AllDomainsAnalysis      = [PSCustomObject]@{
        data     = $domains
        shouldBeArray = $true
    }
    AllPoliciesAnalysis      = [PSCustomObject]@{
        data     = $conditionalAccessPolicies
        shouldBeArray = $true
    }
    SystemInfo = [PSCustomObject]@{
        data     = $scriptData
        shouldBeArray = $false
    }
    AllDevicesAnalysis = [PSCustomObject]@{
        data     = $devices
        shouldBeArray = $true
    }
    RolePoliciesAnalysis = [PSCustomObject]@{
        data     = $rolePolicies
        shouldBeArray = $true
    }
    ErrorMessages = [PSCustomObject]@{
        data     = $script:errors
        shouldBeArray = $true
    }
}
Add-Script-To-Folder -scriptPath $scriptPath -scriptName $scriptName -destination $outputDirectory
Write-Output "Stopping Transcript" | Out-Host
Stop-Transcript
Write-Output "Hashing files" | Out-Host
Hash-Output -outputDirectory $outputDirectory
Log-Success-Message "Files hashed"
Write-Output "Start adding files to the zip file" | Out-Host
New-Zip -zipFileName "$outputDirectory.zip"
Log-Success-Message "Files added to zip file"

if ($DisableFileRemoval.IsPresent -eq $false) {
    Write-Output "Deleting temporary folder" | Out-Host
    try {
        Remove-Temp-Folder -outputDirectory $outputDirectory
    } catch {
        Log-Error-And-Stop "Something went wrong trying to remove temporary folder"
    }
    Log-Success-Message "Succesfully removed temporary folder"
}
# SIG # Begin signature block
# MIItjgYJKoZIhvcNAQcCoIItfzCCLXsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB8AwaCPtIHEYDA
# Vvwo/rmbYzGxP6pthKxn1FjCikjLXKCCJqUwggVyMIIDWqADAgECAhB2U/6sdUZI
# k/Xl10pIOk74MA0GCSqGSIb3DQEBDAUAMFMxCzAJBgNVBAYTAkJFMRkwFwYDVQQK
# ExBHbG9iYWxTaWduIG52LXNhMSkwJwYDVQQDEyBHbG9iYWxTaWduIENvZGUgU2ln
# bmluZyBSb290IFI0NTAeFw0yMDAzMTgwMDAwMDBaFw00NTAzMTgwMDAwMDBaMFMx
# CzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMSkwJwYDVQQD
# EyBHbG9iYWxTaWduIENvZGUgU2lnbmluZyBSb290IFI0NTCCAiIwDQYJKoZIhvcN
# AQEBBQADggIPADCCAgoCggIBALYtxTDdeuirkD0DcrA6S5kWYbLl/6VnHTcc5X7s
# k4OqhPWjQ5uYRYq4Y1ddmwCIBCXp+GiSS4LYS8lKA/Oof2qPimEnvaFE0P31PyLC
# o0+RjbMFsiiCkV37WYgFC5cGwpj4LKczJO5QOkHM8KCwex1N0qhYOJbp3/kbkbuL
# ECzSx0Mdogl0oYCve+YzCgxZa4689Ktal3t/rlX7hPCA/oRM1+K6vcR1oW+9YRB0
# RLKYB+J0q/9o3GwmPukf5eAEh60w0wyNA3xVuBZwXCR4ICXrZ2eIq7pONJhrcBHe
# OMrUvqHAnOHfHgIB2DvhZ0OEts/8dLcvhKO/ugk3PWdssUVcGWGrQYP1rB3rdw1G
# R3POv72Vle2dK4gQ/vpY6KdX4bPPqFrpByWbEsSegHI9k9yMlN87ROYmgPzSwwPw
# jAzSRdYu54+YnuYE7kJuZ35CFnFi5wT5YMZkobacgSFOK8ZtaJSGxpl0c2cxepHy
# 1Ix5bnymu35Gb03FhRIrz5oiRAiohTfOB2FXBhcSJMDEMXOhmDVXR34QOkXZLaRR
# kJipoAc3xGUaqhxrFnf3p5fsPxkwmW8x++pAsufSxPrJ0PBQdnRZ+o1tFzK++Ol+
# A/Tnh3Wa1EqRLIUDEwIrQoDyiWo2z8hMoM6e+MuNrRan097VmxinxpI68YJj8S4O
# JGTfAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB0G
# A1UdDgQWBBQfAL9GgAr8eDm3pbRD2VZQu86WOzANBgkqhkiG9w0BAQwFAAOCAgEA
# Xiu6dJc0RF92SChAhJPuAW7pobPWgCXme+S8CZE9D/x2rdfUMCC7j2DQkdYc8pzv
# eBorlDICwSSWUlIC0PPR/PKbOW6Z4R+OQ0F9mh5byV2ahPwm5ofzdHImraQb2T07
# alKgPAkeLx57szO0Rcf3rLGvk2Ctdq64shV464Nq6//bRqsk5e4C+pAfWcAvXda3
# XaRcELdyU/hBTsz6eBolSsr+hWJDYcO0N6qB0vTWOg+9jVl+MEfeK2vnIVAzX9Rn
# m9S4Z588J5kD/4VDjnMSyiDN6GHVsWbcF9Y5bQ/bzyM3oYKJThxrP9agzaoHnT5C
# JqrXDO76R78aUn7RdYHTyYpiF21PiKAhoCY+r23ZYjAf6Zgorm6N1Y5McmaTgI0q
# 41XHYGeQQlZcIlEPs9xOOe5N3dkdeBBUO27Ql28DtR6yI3PGErKaZND8lYUkqP/f
# obDckUCu3wkzq7ndkrfxzJF0O2nrZ5cbkL/nx6BvcbtXv7ePWu16QGoWzYCELS/h
# AtQklEOzFfwMKxv9cW/8y7x1Fzpeg9LJsy8b1ZyNf1T+fn7kVqOHp53hWVKUQY9t
# W76GlZr/GnbdQNJRSnC0HzNjI3c/7CceWeQIh+00gkoPP/6gHcH1Z3NFhnj0qinp
# J4fGGdvGExTDOUmHTaCX4GUT9Z13Vunas1jHOvLAzYIwggWNMIIEdaADAgECAhAO
# mxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUw
# EwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20x
# JDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEw
# MDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxE
# aWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMT
# GERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprN
# rnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVy
# r2iTcMKyunWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4
# IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13j
# rclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4Q
# kXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQn
# vKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu
# 5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/
# 8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQp
# JYls5Q5SUUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFf
# xCBRa2+xq4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGj
# ggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/
# 57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8B
# Af8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6
# oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElE
# Um9vdENBLmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEB
# AHCgv0NcVec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0a
# FPQTSnovLbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNE
# m0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZq
# aVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCs
# WKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9Fc
# rBjDTZ9ztwGpn1eqXijiuZQwggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5b
# MA0GCSqGSIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5
# NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkG
# A1UEAxMyRGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3Rh
# bXBpbmcgQ0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPB
# PXJJUVXHJQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/
# nR+eDzMfUBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLc
# Z47qUT3w1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mf
# XazL6IRktFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3N
# Ng1c1eYbqMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yem
# j052FVUmcJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g
# 3uM+onP65x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD
# 4L/wojzKQtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDS
# LFc1eSuo80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwM
# O1uKIqjBJgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU
# 7s7pXcheMBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/
# BAgwBgEB/wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0j
# BBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8E
# PDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkUm9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEw
# DQYJKoZIhvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPO
# vxj7x1Bd4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQ
# TGIdDAiCqBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWae
# LJ7giqzl/Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPBy
# oyP6wCeCRK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfB
# wWpx2cYTgAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8l
# Y5knLD0/a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/
# O3itTK37xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbb
# bxV7HhmLNriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3
# OtUVmDG0YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBl
# dkKmKYcJRyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt
# 1nz8MIIGwDCCBKigAwIBAgIQDE1pckuU+jwqSj0pB4A9WjANBgkqhkiG9w0BAQsF
# ADBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNV
# BAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1w
# aW5nIENBMB4XDTIyMDkyMTAwMDAwMFoXDTMzMTEyMTIzNTk1OVowRjELMAkGA1UE
# BhMCVVMxETAPBgNVBAoTCERpZ2lDZXJ0MSQwIgYDVQQDExtEaWdpQ2VydCBUaW1l
# c3RhbXAgMjAyMiAtIDIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDP
# 7KUmOsap8mu7jcENmtuh6BSFdDMaJqzQHFUeHjZtvJJVDGH0nQl3PRWWCC9rZKT9
# BoMW15GSOBwxApb7crGXOlWvM+xhiummKNuQY1y9iVPgOi2Mh0KuJqTku3h4uXoW
# 4VbGwLpkU7sqFudQSLuIaQyIxvG+4C99O7HKU41Agx7ny3JJKB5MgB6FVueF7fJh
# vKo6B332q27lZt3iXPUv7Y3UTZWEaOOAy2p50dIQkUYp6z4m8rSMzUy5Zsi7qlA4
# DeWMlF0ZWr/1e0BubxaompyVR4aFeT4MXmaMGgokvpyq0py2909ueMQoP6McD1AG
# N7oI2TWmtR7aeFgdOej4TJEQln5N4d3CraV++C0bH+wrRhijGfY59/XBT3EuiQMR
# oku7mL/6T+R7Nu8GRORV/zbq5Xwx5/PCUsTmFntafqUlc9vAapkhLWPlWfVNL5Af
# J7fSqxTlOGaHUQhr+1NDOdBk+lbP4PQK5hRtZHi7mP2Uw3Mh8y/CLiDXgazT8QfU
# 4b3ZXUtuMZQpi+ZBpGWUwFjl5S4pkKa3YWT62SBsGFFguqaBDwklU/G/O+mrBw5q
# BzliGcnWhX8T2Y15z2LF7OF7ucxnEweawXjtxojIsG4yeccLWYONxu71LHx7jstk
# ifGxxLjnU15fVdJ9GSlZA076XepFcxyEftfO4tQ6dwIDAQABo4IBizCCAYcwDgYD
# VR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaA
# FLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBRiit7QYfyPMRTtlwvNPSqU
# FN9SnDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3Js
# MIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0Eu
# Y3J0MA0GCSqGSIb3DQEBCwUAA4ICAQBVqioa80bzeFc3MPx140/WhSPx/PmVOZsl
# 5vdyipjDd9Rk/BX7NsJJUSx4iGNVCUY5APxp1MqbKfujP8DJAJsTHbCYidx48s18
# hc1Tna9i4mFmoxQqRYdKmEIrUPwbtZ4IMAn65C3XCYl5+QnmiM59G7hqopvBU2AJ
# 6KO4ndetHxy47JhB8PYOgPvk/9+dEKfrALpfSo8aOlK06r8JSRU1NlmaD1TSsht/
# fl4JrXZUinRtytIFZyt26/+YsiaVOBmIRBTlClmia+ciPkQh0j8cwJvtfEiy2JIM
# kU88ZpSvXQJT657inuTTH4YBZJwAwuladHUNPeF5iL8cAZfJGSOA1zZaX5YWsWMM
# xkZAO85dNdRZPkOaGK7DycvD+5sTX2q1x+DzBcNZ3ydiK95ByVO5/zQQZ/YmMph7
# /lxClIGUgp2sCovGSxVK05iQRWAzgOAj3vgDpPZFR+XOuANCR+hBNnF3rf2i6Jd0
# Ti7aHh2MWsgemtXC8MYiqE+bvdgcmlHEL5r2X6cnl7qWLoVXwGDneFZ/au/ClZpL
# EQLIgpzJGgV8unG1TnqZbPTontRamMifv427GFxD9dAq6OJi7ngE273R+1sKqHB+
# 8JeEeOMIA11HLGOoJTiXAdI/Otrl5fbmm9x+LMz/F0xNAKLY1gEOuIvu5uByVYks
# Jxlh9ncBjDCCBuYwggTOoAMCAQICEHe9DgOhtwj4VKsGchDZBEcwDQYJKoZIhvcN
# AQELBQAwUzELMAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2Ex
# KTAnBgNVBAMTIEdsb2JhbFNpZ24gQ29kZSBTaWduaW5nIFJvb3QgUjQ1MB4XDTIw
# MDcyODAwMDAwMFoXDTMwMDcyODAwMDAwMFowWTELMAkGA1UEBhMCQkUxGTAXBgNV
# BAoTEEdsb2JhbFNpZ24gbnYtc2ExLzAtBgNVBAMTJkdsb2JhbFNpZ24gR0NDIFI0
# NSBDb2RlU2lnbmluZyBDQSAyMDIwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEA1kJN+eNPxiP0bB2BpjD3SD3P0OWN5SAilgdENV0Gzw8dcGDmJlT6UyNg
# AqhfAgL3jsluPal4Bb2O9U8ZJJl8zxEWmx97a9Kje2hld6vYsSw/03IGMlxbrFBn
# LCVNVgY2/MFiTH19hhaVml1UulDQsH+iRBnp1m5sPhPCnxHUXzRbUWgxYwr4W9De
# ullfMa+JaDhAPgjoU2dOY7Yhju/djYVBVZ4cvDfclaDEcacfG6VJbgogWX6Jo1gV
# lwAlad/ewmpQZU5T+2uhnxgeig5fVF694FvP8gwE0t4IoRAm97Lzei7CjpbBP86l
# 2vRZKIw3ZaExlguOpHZ3FUmEZoIl50MKd1KxmVFC/6Gy3ZzS3BjZwYapQB1Bl2KG
# vKj/osdjFwb9Zno2lAEgiXgfkPR7qVJOak9UBiqAr57HUEL6ZQrjAfSxbqwOqOOB
# Gag4yJ4DKIakdKdHlX5yWip7FWocxGnmsL5AGZnL0n1VTiKcEOChW8OzLnqLxN7x
# Sx+MKHkwRX9sE7Y9LP8tSooq7CgPLcrUnJiKSm1aNiwv37rL4kFKCHcYiK01YZQS
# 86Ry6+42nqdRJ5E896IazPyH5ZfhUYdp6SLMg8C3D0VsB+FDT9SMSs7PY7G1pBB6
# +Q0MKLBrNP4haCdv7Pj6JoRbdULNiSZ5WZ1rq2NxYpAlDQgg8f8CAwEAAaOCAa4w
# ggGqMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDAzASBgNVHRMB
# Af8ECDAGAQH/AgEAMB0GA1UdDgQWBBTas43AJJCja3fTDKBZ3SFnZHYLeDAfBgNV
# HSMEGDAWgBQfAL9GgAr8eDm3pbRD2VZQu86WOzCBkwYIKwYBBQUHAQEEgYYwgYMw
# OQYIKwYBBQUHMAGGLWh0dHA6Ly9vY3NwLmdsb2JhbHNpZ24uY29tL2NvZGVzaWdu
# aW5ncm9vdHI0NTBGBggrBgEFBQcwAoY6aHR0cDovL3NlY3VyZS5nbG9iYWxzaWdu
# LmNvbS9jYWNlcnQvY29kZXNpZ25pbmdyb290cjQ1LmNydDBBBgNVHR8EOjA4MDag
# NKAyhjBodHRwOi8vY3JsLmdsb2JhbHNpZ24uY29tL2NvZGVzaWduaW5ncm9vdHI0
# NS5jcmwwVgYDVR0gBE8wTTBBBgkrBgEEAaAyATIwNDAyBggrBgEFBQcCARYmaHR0
# cHM6Ly93d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wCAYGZ4EMAQQBMA0G
# CSqGSIb3DQEBCwUAA4ICAQAIiHImxq/6rF8GwKqMkNrQssCil/9uEzIWVP0+9DAR
# n4+Y+ZtS3fKiFu7ZeJWmmnxhuAS1+OvL9GERM/ZlJbcRQovYaW7H/5W0gUOpfq6/
# gtZNzBGjg3FqEF4ZBafnbH9W9Khcw04JrVlruPl+pS64/N4OwqD7sATUExvHJ6m5
# qi0xO89GTJ3rTOy8Lpzxh6N/OGlfQUBn9lN96kHvjj37qdQROEbfPOv2zSK9E83w
# 4eblM6C+POR41RvMIPIwc7AiHPaE1ptcAALhKFJL/xJLQOrusBoGBp6E5ufw24RG
# +3PZK0K2yVc0xxbApushuaoO9/7byuu8F8u4Z+vjPk/bqZSGZFXJCQrA2QRxShFL
# WmTDvHh4rUxHJmUHmdXNNmChM1Oz9nsq1YlAPHGlq/iZWf3jm5JL3QW9Cwx4BivP
# U9i9EppbJ4aFP5G+4HiAc1Tfpx1nK2q2rk2JgCQIUnBQ8wH/RK4vmuDhSQjh4VvX
# ONGeCoqdlCebyqO52+I2auNvuVhi4DZ4NgH6waeJeiZTo1y70rLristjCC/+HvNW
# KeI1m9j/6aW9bUtZLIksL1K7tSmQ2kNHvHLdvNm/gMHcsKu0Sx1YNjdk65vhhRea
# KaL95gjSkv+g+Hzh6afRMI5fJlArx6Lil3eK79hNPibrmUBg8zxnDLYIcik1U4E0
# 3DCCBzowggUioAMCAQICDDzpOX70kq0pLEiDTTANBgkqhkiG9w0BAQsFADBZMQsw
# CQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEvMC0GA1UEAxMm
# R2xvYmFsU2lnbiBHQ0MgUjQ1IENvZGVTaWduaW5nIENBIDIwMjAwHhcNMjIwNDE0
# MTAyMDMyWhcNMjUwNDE0MTAyMDMyWjCBpzELMAkGA1UEBhMCTkwxFjAUBgNVBAgT
# DU5vb3JkLUhvbGxhbmQxEjAQBgNVBAcTCUFtc3RlcmRhbTEkMCIGA1UEChMbUHJp
# Y2V3YXRlcmhvdXNlQ29vcGVycyBCLlYuMSQwIgYDVQQDExtQcmljZXdhdGVyaG91
# c2VDb29wZXJzIEIuVi4xIDAeBgkqhkiG9w0BCQEWEW5sX3Nha2l0YUBwd2MuY29t
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAoPUdxgVAsNEsTLjGZc9W
# Fx+J4yIt9DyRTSpGc2agEvRotFrY34QZkpRg6XtzKleCCdZ2+7tZkmBDkG0UbvDb
# KiBW8G8PPBIppZkO/FEjplWbJakGfETrJHcqYS1aKzNZF6FghodY2qytQyb0q4J5
# /smgR2wOtXK4mcD8B5AnKZStIU5DZ+AAGvT/KjL22dXX9KnkCXCGdscsueHTX7qM
# 0umbbYuBspYH937lLrV+0owifbPqgMr9Tjdd8oQRcAC3GziCPtYTjcJAdBfkmiOD
# 5mWG4tvXdpoTev3XiqYqtudArgimFriUTaZ4THDwkOQLj58vTtfvsy2JLDCaqrCh
# r0QkMMZxgzM/Ko9O7bilseA3jJ5I9por8Ax3fmkk9gJuSxkxSjkJmxXsXutSGlOA
# 8gmCxTVDQm3DmkemgMjQxIe4hkVzgKYf0srFAlOIi+k0zpqAQFeQQDXHtvHSzL5V
# 4YaWuWv6tGwuK2kq2IaPafaqAAIYBHpttSIiicneezzOEQxkO+KofALih77WYCU8
# gbrJdkry/lCNr6BzJmHKtodqtnPV7TXALAcuj7A3e6wqrA02ioHWJ1Pl8Yix7UmF
# DNnlZSUWg+vU/lZKRDR5XqlDRzf0KAdmmDChCyAWRTs0sIbiQwATO6k2D/T2MlQT
# S20yUMTewv41HSVrb+lIAXECAwEAAaOCAbEwggGtMA4GA1UdDwEB/wQEAwIHgDCB
# mwYIKwYBBQUHAQEEgY4wgYswSgYIKwYBBQUHMAKGPmh0dHA6Ly9zZWN1cmUuZ2xv
# YmFsc2lnbi5jb20vY2FjZXJ0L2dzZ2NjcjQ1Y29kZXNpZ25jYTIwMjAuY3J0MD0G
# CCsGAQUFBzABhjFodHRwOi8vb2NzcC5nbG9iYWxzaWduLmNvbS9nc2djY3I0NWNv
# ZGVzaWduY2EyMDIwMFYGA1UdIARPME0wQQYJKwYBBAGgMgEyMDQwMgYIKwYBBQUH
# AgEWJmh0dHBzOi8vd3d3Lmdsb2JhbHNpZ24uY29tL3JlcG9zaXRvcnkvMAgGBmeB
# DAEEATAJBgNVHRMEAjAAMEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9jcmwuZ2xv
# YmFsc2lnbi5jb20vZ3NnY2NyNDVjb2Rlc2lnbmNhMjAyMC5jcmwwEwYDVR0lBAww
# CgYIKwYBBQUHAwMwHwYDVR0jBBgwFoAU2rONwCSQo2t30wygWd0hZ2R2C3gwHQYD
# VR0OBBYEFLVpaSa7lzdMIqFjWogzmeJXEUOaMA0GCSqGSIb3DQEBCwUAA4ICAQBy
# Ly6e65woR2zfE2tCR4l/L+9MpeTIMWrFiLe0O4nMqqXQHJAuNX9n30k+rkC9A7X+
# zgDOTEbz/LkfWk77rrrra13vQjwc2xIfIPErbiTVNzgJasPu1Kys0QWldTYVOJLG
# 7PiIoieVRY4lhpMwTWAvQgEz6rOMbnU+7bM67qewcEG5aBXGZXf9knFQ/UkaBt4f
# t7A1oT3JEMkJCvTKudFeaf/KQaYnpck6TJBelSB6MInSeeZzTKZmKBQ+JuK+nVPw
# n8fAwbdifRviAmnCfq6Bl2MmZ9Zp6O1nihj9yv9cL7SQ9O2ya4L3x6Q6ufVJxJ6V
# e95X7t+NMtXm955zoZBflelzVYaGmZwBYoW+oTx7YVGC3jiVtLIfwWHOaw8Yb7yG
# 3CxsA1pxP7oD0oIdsoeY7YNE/fpTwuHx0Oiq3M5VgbDZhiX4DjcNnfDl17ybFsRk
# VjmAUbCIusVyIqKsyRbIcvV/T/IKTjYvg1BSkn4y2Zbywm/ALm2XbNS0VZNMFppX
# z1B4am8YzXpbVQv3FVFl9fJD7UcL2YFDuqVY31QvAGVhBGUY0I0/MNb7jzuErini
# +YG9n/dxUcKCjDp4ZLFmtchAXpiNFSpxmG3UkGxSuhELVu7TnG2B9aIT80ZBHHRK
# Xdpfj/2siC8Km7XfTONZFrHdzMDesZbDXZtoMK4sHjGCBj8wggY7AgEBMGkwWTEL
# MAkGA1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExLzAtBgNVBAMT
# Jkdsb2JhbFNpZ24gR0NDIFI0NSBDb2RlU2lnbmluZyBDQSAyMDIwAgw86Tl+9JKt
# KSxIg00wDQYJYIZIAWUDBAIBBQCggYQwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKA
# ADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYK
# KwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgEpHAVHlVkZP/HxoDVQ56ouyjXj85
# 3tvA1XtHkS4qPlwwDQYJKoZIhvcNAQEBBQAEggIARaGpTlkyprP3tc4WjvLx5kMG
# GnE4yAn2KbHrrw9CwmEasLJvEieuTsRfivVoZhui083L3GqMd+uai1kAQceh1DpV
# avDD65iQrTEgrWKqZW2N1iuJGF0Qfh0hawem4i/mXf240EuFdBwVbe1KG7IFU5a6
# 0qweOVI8NMxyulsK+WAwY77LJb8hE2AqYg24i/f0OrkQPPrsP2RpZqoq3iSrSjW9
# ibZYC2cmvL6gsRe9YKKdnxK82WPc0jnXVed+Q2eiy+nL/Vshm7Hn8qcrPiDDfDj4
# PTUtRECdXE58erfV9YrKLgjt13T19iRu6oXID55wzRcHBqUjjROcuTStiw4FSZTg
# EoADvOjgY7+T5kXXWQx3mlK2or5Ds/sq4FL1RcYIxhucS/72QRSrxYdyJplloHyG
# aMrGXsUuEq8q2uUFxGLNFX2CQ8hmRGcdzhLDsKMV5h9fUImv1xnfIJs/CGsvCO+q
# ZRCPbniA1zC6mYStnuLWt6/gCfphq4gb0/zt5hn1cdNekKvKt+AhxG3oJmSjXBdu
# siecmK/oDcVwWzRLt8UYiK6ow/mAzBcvWHnzYW/91kSSyj3Udxt0EMben2RxoSnI
# 0ilFPbM4KNDD0cY1bLM4DXb/WD8dEkItqi/PLa+7zKyrooTBMPBBYul6HyIy1fa+
# OV1u1CBgGhMydF8t/0ShggMgMIIDHAYJKoZIhvcNAQkGMYIDDTCCAwkCAQEwdzBj
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
# MkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5n
# IENBAhAMTWlyS5T6PCpKPSkHgD1aMA0GCWCGSAFlAwQCAQUAoGkwGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNTI0MjEwNzM2WjAv
# BgkqhkiG9w0BCQQxIgQgvcl7Hk+WsQqE2qmP971J5Z0KEfoPTyEd75eyo9rwZfYw
# DQYJKoZIhvcNAQEBBQAEggIAc9fB89/IT3NgeULyCm/0YSTkVSQXPTt2oma3awGj
# zP6o9VsLGqaoQ1K9MXngUePrNpty+VhK5FvjDMTJKpLg90d7VuemSbJr7kb1hbMa
# WZv2eq5HU2h1wbDP4y5FYbG7Hw6fwQBImSqPjB6OdTAHRxB7JY6V/Qm1QjNBbzDQ
# /oIBuIkgbvHss560qrebSr1YsNBR461S+9ZIgPQncL3hfW0wHaTI/+rI3SCmowZe
# loQUSEKltX2YIl76i/3+uHgfValRPCAVazgC3QDl1jS/aKKn/MXyeoQdNAu53ud8
# 5Itr95tAcWVjxiOJ1suFuYRMqf8khmqqkWGDu3JTYX3H/lBW3fqrLa2DuuTplf2r
# N7HEZeSTxIVMaqIenHXPEjetjLRknD+sn5abs1UQVHdtktC0mydls+ucEE8AOyr5
# sAuFo0FldLOqmR0xr1WQTBtvFu82WhxryOBmnAegU9SjmeY8ntbpaZVe0EiDNeDG
# mWgVk2eKCqHhR9BEuyaSxP46BUa1y3bqRsPK8QiFRIvFBIL/kVjQ33RcXMUNOK3a
# eMPdUF9b+OYWFZYBvkgMLHk0o7j5QbXiUCFNEhRyewl6X//YSkrB0M/BE7N3jNtt
# SGqPyCz0upSL+yySafSK411VQrcdKc3kUhCn2jW1WtMgw7SMFcJmlly77Z582Ant
# 9rE=
# SIG # End signature block
